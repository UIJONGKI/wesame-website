<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>라라벨 입문</title>
	@yield('style')
</head>
<body>
	
	@yield('content')
	
	@yield('script')
</body>
</html>