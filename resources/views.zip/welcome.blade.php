@extends('layouts.app')

@section('content')
    <div class="container">
    	<h1>메인페이지</h1>
    </div>
@endsection
