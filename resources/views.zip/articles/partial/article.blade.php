<div class="media">
	<!--썸네일 넣을 곳-->

	<!-- 글 목록 -->
	<div class="media-body">
		<a href="{{ route('articles.show', $article->id) }}"><h4 class="media-heading">{{ $article->title }}</h4></a>

		<p class="text-muted">
			<i class="fa fa-user"></i> {{ $article->user->name }}
			<i class="fa-clock-o"></i> {{ $article->created_at->diffForHumans() }}
		</p>
		
		@if($viewName === 'articles.index')
			@include('tags.partial.list', ['tags' => $article->tags])
		@endif
		@if($viewName === 'articles.show')
			@include('attachments.partial.list', ['attachments' => $article->attachments])
		@endif
	</div>
</div>